import { FormEvent } from 'react';

export type NavigationPropsType = {
  onAddMarkdown: (e: FormEvent<HTMLButtonElement>) => void;
};
