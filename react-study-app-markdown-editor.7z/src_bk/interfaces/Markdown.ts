export interface Markdown {
  id?: string;
  source?: string;
}
